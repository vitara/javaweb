package com.enation.app.base.core.plugin.sms;

import com.enation.app.base.core.model.SmsPlatform;

public class AbstractSmsComponent {

	public static void addSms(SmsPlatform smsPlatform){
		
	}
	
}
