package com.enation.app.base.core.service.dbsolution.impl;

/**
 * 导入、导出类的公共部分
 * @author liuzy
 * 
 */
public class DBPorter {
	
	protected DBSolution solution;

	public DBPorter(DBSolution solution) {
		this.solution = solution;
	}
}
