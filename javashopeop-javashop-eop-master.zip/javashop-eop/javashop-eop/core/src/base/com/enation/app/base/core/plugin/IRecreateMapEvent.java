package com.enation.app.base.core.plugin;

import java.util.List;

public interface IRecreateMapEvent {
	public void onRecreateMap();
}
