package com.enation.app.base.core.service;

public class SettingRuntimeException extends RuntimeException {
	public  SettingRuntimeException(String message){
		super(message);
	}
}
