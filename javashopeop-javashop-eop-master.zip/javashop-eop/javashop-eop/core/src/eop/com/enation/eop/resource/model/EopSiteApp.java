package com.enation.eop.resource.model;

/**
 * @author lzf
 *         <p>
 *         created_time 2009-12-10 下午06:31:41
 *         </p>
 * @version 1.0
 */
public class EopSiteApp extends Resource {

}
