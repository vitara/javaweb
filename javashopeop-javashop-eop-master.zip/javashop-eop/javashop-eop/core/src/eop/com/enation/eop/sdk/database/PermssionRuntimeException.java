package com.enation.eop.sdk.database;

public class PermssionRuntimeException extends RuntimeException {

}
